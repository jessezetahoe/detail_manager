@echo off
setlocal
cd /d "%~dp0"

py -3 -c "import fitz" >nul 2>&1
if errorlevel 1 (
    echo Installing PyMuPDF...
    py -3 -m pip install pymupdf
    if errorlevel 1 (
        echo.
        echo PyMuPDF installation failed.
        pause
        exit /b 1
    )
)

py -3 detail_manager.py
if errorlevel 1 (
    echo.
    echo Detail Manager exited with an error.
    pause
)
